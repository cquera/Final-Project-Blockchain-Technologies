import pytest
from brownie import Wei, reverts

def test_fund_raising_contract(accounts, FundRaisingContract):
    # Deploy the FundRaisingContract
    fund_raising_contract = FundRaisingContract.deploy({'from': accounts[0]})

    # Check initial total funds raised and total tokens sold
    assert fund_raising_contract.totalFundsRaised() == 0
    assert fund_raising_contract.totalTokensSold() == 0

    # Buy tokens and raise funds
    fund_raising_contract.buyTokens({'from': accounts[1], 'value': Wei("1 ether")})
    fund_raising_contract.buyTokens({'from': accounts[2], 'value': Wei("2 ether")})

    # Check balances
    assert fund_raising_contract.balances(accounts[1]) == Wei("1 ether")
    assert fund_raising_contract.balances(accounts[2]) == Wei("2 ether")

    # Check total funds raised and total tokens sold
    assert fund_raising_contract.totalFundsRaised() == Wei("3 ether")
    assert fund_raising_contract.totalTokensSold() == Wei("3 ether")

    # Withdraw funds
    fund_raising_contract.withdrawFunds(Wei("2 ether"), {'from': accounts[0]})

    # Check remaining balance
    assert fund_raising_contract.totalFundsRaised() == Wei("1 ether")

    # Trying to withdraw more funds than available should revert
    with reverts("Insufficient balance"):
        fund_raising_contract.withdrawFunds(Wei("2 ether"), {'from': accounts[0]})
# tests/TicketingTest.py
import pytest
import time
from brownie import DutchAuctionTicketing, accounts, reverts


@pytest.fixture(scope="module")
def ticketing_contract():
    auction_duration = 10  # 10 seconds
    min_ticket_price = 1
    total_tickets = 3
    contract = DutchAuctionTicketing.deploy(
        10, auction_duration, min_ticket_price, total_tickets, {"from": accounts[0]}
    )
    yield contract


def test_dutch_auction_ticketing(ticketing_contract):
    buyer = accounts[1]
    club = accounts[0]


    # Check initial ticket price and owner
    assert ticketing_contract.ticketPrice() == 10
    assert ticketing_contract.ticketOwners(1) == "0x0000000000000000000000000000000000000000"
    assert ticketing_contract.getAvailableTickets() == 3

    # Purchase ticket
    nextTicketId = 1
    ticketing_contract.buyTicket(nextTicketId, {"from": buyer, "value": 10})

    # Check updated ticket price, owner, and available tickets
    assert ticketing_contract.ticketPrice() == 10
    assert ticketing_contract.ticketOwners(1) == buyer
    assert ticketing_contract.getAvailableTickets() == 2

    # Wait for auction duration to pass
    time.sleep(10)

    # End the auction
    ticketing_contract.endAuction({"from": club})

    # Check updated ticket price
    assert ticketing_contract.ticketPrice() == 9
    print(ticketing_contract.ticketPrice())

    # Attempt to purchase ticket below minimum price should fail
    with reverts("Insufficient payment"):
        ticketing_contract.buyTicket(nextTicketId, {"from": buyer, "value": 8})
    

    # Purchase ticket at reduced price
    ticketing_contract.buyTicket(nextTicketId, {"from": buyer, "value": 9})

    # Check updated ticket owner and available tickets
    assert ticketing_contract.ticketOwners(2) == buyer
    assert ticketing_contract.getAvailableTickets() == 1
